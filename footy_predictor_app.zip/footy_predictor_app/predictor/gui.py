from __future__ import annotations
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from pathlib import Path
import json
import pandas as pd

from .io_utils import (
    read_csv_any,
    normalise_match_file,
    split_results_fixtures,
    latest_download_file,
    filter_by_division,
)
from .categories import load_categories, save_categories
from .engine import MatchPredictor
from .models import PredictorConfig
from .downloader import COUNTRY_LEAGUES, default_season_code, download_football_data_files
from .weight_tuner import WeightTuner


class PredictorGUI(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Football Match Predictor")
        self.geometry("1320x820")
        self.download_dir = tk.StringVar(value=str(Path.home() / "Downloads"))
        self.results_path = tk.StringVar()
        self.fixtures_path = tk.StringVar()
        app_base = Path(__file__).resolve().parent.parent
        self.categories_path = tk.StringVar(value=str((app_base / "team_categories.json").resolve()))
        self.lookback_var = tk.IntVar(value=6)
        self.threshold_var = tk.DoubleVar(value=2.0)
        self.min_games_var = tk.IntVar(value=30)
        self.max_lookback_var = tk.IntVar(value=10)
        self.min_week_games_var = tk.IntVar(value=6)

        self.data_source_var = tk.StringVar(value="football-data.co.uk")
        self.country_var = tk.StringVar(value="England")
        self.league_display_var = tk.StringVar()
        self.season_code_var = tk.StringVar(value=default_season_code())
        self.status_var = tk.StringVar(value="Ready")

        self.results_df = None
        self.fixtures_df = None
        self.all_df = None
        self.predictions_df = pd.DataFrame()
        self.backtest_df = pd.DataFrame()
        self.category_editor_win = None
        self.category_row_vars = {}
        self.category_seed_vars = {}
        self.weight_profile = None  # dict from tuner / JSON
        self.tune_candidates_var = tk.IntVar(value=120)
        self.tune_train_seasons_var = tk.StringVar(value="")
        self.tune_valid_seasons_var = tk.StringVar(value="")
        self.tuning_df = pd.DataFrame()
        self.weekly_summary_df = pd.DataFrame()
        self.weekly_details_df = pd.DataFrame()

        self._build_ui()
        self._refresh_leagues_for_country()

    def _build_ui(self):
        top = ttk.Frame(self, padding=10)
        top.pack(fill="x")
        top.columnconfigure(1, weight=1)

        ttk.Label(top, text="Source").grid(row=0, column=0, sticky="w")
        ttk.Combobox(top, textvariable=self.data_source_var, values=["football-data.co.uk"], width=22, state="readonly").grid(row=0, column=1, sticky="w")

        ttk.Label(top, text="Country").grid(row=0, column=2, sticky="w", padx=(12, 0))
        self.country_combo = ttk.Combobox(top, textvariable=self.country_var, values=list(COUNTRY_LEAGUES.keys()), width=16, state="readonly")
        self.country_combo.grid(row=0, column=3, sticky="w")
        self.country_combo.bind("<<ComboboxSelected>>", lambda e: self._refresh_leagues_for_country())

        ttk.Label(top, text="League").grid(row=0, column=4, sticky="w", padx=(12, 0))
        self.league_combo = ttk.Combobox(top, textvariable=self.league_display_var, values=[], width=28, state="readonly")
        self.league_combo.grid(row=0, column=5, sticky="w")

        ttk.Label(top, text="Season code").grid(row=0, column=6, sticky="w", padx=(12, 0))
        ttk.Entry(top, textvariable=self.season_code_var, width=8).grid(row=0, column=7, sticky="w")
        ttk.Button(top, text="Download latest results CSV", command=self.download_results).grid(row=0, column=8, padx=4)
        ttk.Button(top, text="Download this week's fixtures", command=self.download_fixtures).grid(row=0, column=9, padx=4)
        ttk.Button(top, text="Download both", command=self.download_both).grid(row=0, column=10, padx=4)

        ttk.Label(top, text="Downloads folder").grid(row=1, column=0, sticky="w", pady=(8, 0))
        ttk.Entry(top, textvariable=self.download_dir, width=78).grid(row=1, column=1, columnspan=7, sticky="ew", padx=6, pady=(8, 0))
        ttk.Button(top, text="Browse", command=self.pick_download_dir).grid(row=1, column=8, pady=(8, 0))
        ttk.Button(top, text="Auto-find latest files", command=self.autofind_files).grid(row=1, column=9, columnspan=2, padx=6, pady=(8, 0))

        ttk.Label(top, text="Results CSV/XLSX").grid(row=2, column=0, sticky="w", pady=(8, 0))
        ttk.Entry(top, textvariable=self.results_path, width=78).grid(row=2, column=1, columnspan=7, sticky="ew", padx=6, pady=(8, 0))
        ttk.Button(top, text="Browse", command=lambda: self.pick_file(self.results_path)).grid(row=2, column=8, pady=(8, 0))

        ttk.Label(top, text="Fixtures CSV/XLSX").grid(row=3, column=0, sticky="w", pady=(8, 0))
        ttk.Entry(top, textvariable=self.fixtures_path, width=78).grid(row=3, column=1, columnspan=7, sticky="ew", padx=6, pady=(8, 0))
        ttk.Button(top, text="Browse", command=lambda: self.pick_file(self.fixtures_path)).grid(row=3, column=8, pady=(8, 0))

        ttk.Label(top, text="Categories JSON").grid(row=4, column=0, sticky="w", pady=(8, 0))
        ttk.Entry(top, textvariable=self.categories_path, width=78).grid(row=4, column=1, columnspan=7, sticky="ew", padx=6, pady=(8, 0))
        ttk.Button(top, text="Edit categories", command=self.edit_categories).grid(row=4, column=8, pady=(8, 0))

        opts = ttk.Frame(self, padding=(10, 0, 10, 6))
        opts.pack(fill="x")
        ttk.Label(opts, text="Lookback").grid(row=0, column=0)
        ttk.Spinbox(opts, from_=3, to=25, textvariable=self.lookback_var, width=6).grid(row=0, column=1, padx=4)
        ttk.Label(opts, text="Threshold").grid(row=0, column=2)
        ttk.Spinbox(opts, from_=0, to=20, increment=0.5, textvariable=self.threshold_var, width=6).grid(row=0, column=3, padx=4)
        ttk.Label(opts, text="Min backtest games").grid(row=0, column=4, padx=(14, 2))
        ttk.Spinbox(opts, from_=0, to=1000, textvariable=self.min_games_var, width=6).grid(row=0, column=5, padx=4)
        ttk.Label(opts, text="Max lookback grid").grid(row=0, column=6, padx=(14, 2))
        ttk.Spinbox(opts, from_=3, to=30, textvariable=self.max_lookback_var, width=6).grid(row=0, column=7, padx=4)
        ttk.Label(opts, text="Min week games").grid(row=0, column=8, padx=(14, 2))
        ttk.Spinbox(opts, from_=1, to=20, textvariable=self.min_week_games_var, width=6).grid(row=0, column=9, padx=4)
        ttk.Button(opts, text="Load files", command=self.load_files).grid(row=0, column=10, padx=8)
        ttk.Button(opts, text="Backtest (grid)", command=self.run_backtest).grid(row=0, column=11, padx=8)
        ttk.Button(opts, text="Predict this week's fixtures", command=self.run_predictions).grid(row=0, column=12, padx=8)
        ttk.Button(opts, text="Tune weights (historical)", command=self.run_weight_tuning).grid(row=0, column=13, padx=8)
        ttk.Button(opts, text="Weekly performance", command=self.run_weekly_performance).grid(row=0, column=14, padx=8)
        ttk.Button(opts, text="Export predictions CSV", command=self.export_predictions).grid(row=0, column=15, padx=8)

        self.notebook = ttk.Notebook(self)
        self.notebook.pack(fill="both", expand=True, padx=10, pady=10)

        self.preview_text = tk.Text(self.notebook, wrap="none")
        self.notebook.add(self.preview_text, text="Data Preview")

        self.backtest_frame = ttk.Frame(self.notebook)
        self.backtest_tree = self._make_treeview(self.backtest_frame)
        self.backtest_tree.bind("<Double-1>", self._on_backtest_double_click)
        self.notebook.add(self.backtest_frame, text="Backtest")

        self.pred_frame = ttk.Frame(self.notebook)
        self.pred_tree = self._make_treeview(self.pred_frame)
        self.notebook.add(self.pred_frame, text="Predictions")

        self.weekly_frame = ttk.Frame(self.notebook)
        weekly_top = ttk.Frame(self.weekly_frame, padding=6)
        weekly_top.pack(fill="x")
        ttk.Label(weekly_top, text="Weekly performance summary (double-click row to apply lookback/threshold and load week details)").pack(side="left")
        self.weekly_tree = self._make_treeview(self.weekly_frame)
        self.weekly_tree.bind("<Double-1>", self._on_weekly_summary_double_click)
        self.notebook.add(self.weekly_frame, text="Weekly Performance")

        self.weekly_detail_frame = ttk.Frame(self.notebook)
        weekly_detail_top = ttk.Frame(self.weekly_detail_frame, padding=6)
        weekly_detail_top.pack(fill="x")
        self.weekly_detail_label_var = tk.StringVar(value="Double-click a Weekly Performance row to see per-week results")
        ttk.Label(weekly_detail_top, textvariable=self.weekly_detail_label_var).pack(side="left")
        self.weekly_detail_tree = self._make_treeview(self.weekly_detail_frame)
        self.notebook.add(self.weekly_detail_frame, text="Weekly Detail")

        self.tuning_frame = ttk.Frame(self.notebook)
        tune_top = ttk.Frame(self.tuning_frame, padding=6)
        tune_top.pack(fill="x")
        ttk.Label(tune_top, text="Train seasons (comma, blank=loaded season)").grid(row=0, column=0, sticky="w")
        ttk.Entry(tune_top, textvariable=self.tune_train_seasons_var, width=22).grid(row=0, column=1, padx=4)
        ttk.Label(tune_top, text="Valid seasons (comma, optional)").grid(row=0, column=2, sticky="w", padx=(12,0))
        ttk.Entry(tune_top, textvariable=self.tune_valid_seasons_var, width=22).grid(row=0, column=3, padx=4)
        ttk.Label(tune_top, text="Candidates").grid(row=0, column=4, padx=(12,0))
        ttk.Spinbox(tune_top, from_=20, to=5000, increment=10, textvariable=self.tune_candidates_var, width=8).grid(row=0, column=5, padx=4)
        ttk.Button(tune_top, text="Run tuning", command=self.run_weight_tuning).grid(row=0, column=6, padx=6)
        ttk.Button(tune_top, text="Save tuned profile JSON", command=self.save_tuned_profile).grid(row=0, column=7, padx=6)
        self.tuning_tree = self._make_treeview(self.tuning_frame)
        self.tuning_tree.bind("<Double-1>", self._on_tuning_double_click)
        self.notebook.add(self.tuning_frame, text="Weight Tuning")

        status = ttk.Label(self, textvariable=self.status_var, relief="sunken", anchor="w")
        status.pack(fill="x", side="bottom")

    def _refresh_leagues_for_country(self):
        country = self.country_var.get() or "England"
        choices = [name for name, _ in COUNTRY_LEAGUES.get(country, [])]
        self.league_combo["values"] = choices
        if not self.league_display_var.get() or self.league_display_var.get() not in choices:
            if choices:
                self.league_display_var.set(choices[0])

    @property
    def selected_div_code(self) -> str:
        country = self.country_var.get() or "England"
        league = self.league_display_var.get()
        for name, code in COUNTRY_LEAGUES.get(country, []):
            if name == league:
                return code
        return "E0"

    def _make_treeview(self, parent):
        frame = ttk.Frame(parent)
        frame.pack(fill="both", expand=True)
        tree = ttk.Treeview(frame, show="headings")
        vsb = ttk.Scrollbar(frame, orient="vertical", command=tree.yview)
        hsb = ttk.Scrollbar(frame, orient="horizontal", command=tree.xview)
        tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        tree.grid(row=0, column=0, sticky="nsew")
        vsb.grid(row=0, column=1, sticky="ns")
        hsb.grid(row=1, column=0, sticky="ew")
        frame.rowconfigure(0, weight=1)
        frame.columnconfigure(0, weight=1)
        return tree

    def _sort_treeview(self, tree, col, descending=False):
        rows = [(tree.set(k, col), k) for k in tree.get_children("")]
        def convert(v):
            s = "" if v is None else str(v).strip()
            if s == "" or s.lower() in {"nan", "none", "nat"}:
                return (2, "")
            try:
                return (0, float(s))
            except Exception:
                return (1, s.lower())
        rows.sort(key=lambda x: convert(x[0]), reverse=descending)
        for idx, (_, k) in enumerate(rows):
            tree.move(k, "", idx)
        tree.heading(col, command=lambda: self._sort_treeview(tree, col, not descending))

    def _show_df_in_tree(self, tree, df: pd.DataFrame):
        tree.delete(*tree.get_children())
        if df is None or df.empty:
            tree["columns"] = []
            return
        cols = [str(c) for c in df.columns]
        tree["columns"] = cols
        for c in cols:
            tree.heading(c, text=c, command=lambda cc=c: self._sort_treeview(tree, cc, False))
            max_len = max(len(c), min(28, int(df[c].astype(str).str.len().fillna(0).max() if len(df) else 0)))
            width = max(90, min(240, max_len * 8))
            anchor = "e" if pd.api.types.is_numeric_dtype(df[c]) else "w"
            tree.column(c, width=width, stretch=True, anchor=anchor)
        display_df = df.copy()
        for c in display_df.columns:
            if pd.api.types.is_datetime64_any_dtype(display_df[c]):
                display_df[c] = display_df[c].dt.strftime("%Y-%m-%d")
        for _, row in display_df.iterrows():
            vals = ["" if pd.isna(v) else str(v) for v in row.tolist()]
            tree.insert("", "end", values=vals)

    def _on_backtest_double_click(self, _event=None):
        item = self.backtest_tree.focus()
        if not item:
            return
        vals = self.backtest_tree.item(item, "values")
        cols = list(self.backtest_tree["columns"])
        if not vals or "lookback" not in cols or "threshold" not in cols:
            return
        row = dict(zip(cols, vals))
        try:
            self.lookback_var.set(int(float(row["lookback"])))
            self.threshold_var.set(float(row["threshold"]))
            self.status_var.set(f"Applied backtest row: lookback={self.lookback_var.get()} threshold={self.threshold_var.get()}")
        except Exception:
            return

    def pick_download_dir(self):
        p = filedialog.askdirectory(initialdir=self.download_dir.get() or str(Path.home()))
        if p:
            self.download_dir.set(p)

    def pick_file(self, var):
        p = filedialog.askopenfilename(filetypes=[("CSV/Excel", "*.csv *.xlsx *.xls"), ("All", "*.*")])
        if p:
            var.set(p)

    def _download_from_source(self):
        if self.data_source_var.get() != "football-data.co.uk":
            raise ValueError("Only football-data.co.uk is wired in right now")
        return download_football_data_files(self.download_dir.get(), self.selected_div_code, self.season_code_var.get().strip() or None)

    def download_results(self):
        try:
            files = self._download_from_source()
            self.results_path.set(str(files.results_path))
            self.status_var.set(f"Downloaded results to {files.results_path}")
            messagebox.showinfo("Downloaded", f"Results CSV saved:\n{files.results_path}")
        except Exception as e:
            messagebox.showerror("Download failed", str(e))

    def download_fixtures(self):
        try:
            files = self._download_from_source()
            self.fixtures_path.set(str(files.fixtures_path))
            self.status_var.set(f"Downloaded fixtures to {files.fixtures_path}")
            messagebox.showinfo("Downloaded", f"Fixtures CSV saved:\n{files.fixtures_path}")
        except Exception as e:
            messagebox.showerror("Download failed", str(e))

    def download_both(self):
        try:
            files = self._download_from_source()
            self.results_path.set(str(files.results_path))
            self.fixtures_path.set(str(files.fixtures_path))
            self.status_var.set("Downloaded results + fixtures")
            messagebox.showinfo("Downloaded", f"Results: {files.results_path}\nFixtures: {files.fixtures_path}")
        except Exception as e:
            messagebox.showerror("Download failed", str(e))

    def autofind_files(self):
        d = self.download_dir.get()
        div = self.selected_div_code
        season = self.season_code_var.get().strip()
        results = latest_download_file(d, [f"{div}_{season}_results.csv", f"{div}.csv", "*results*.csv", "*result*.csv", "*.xlsx"])
        fixtures = latest_download_file(d, ["football-data_fixtures.csv", "*fixtures*.csv", "*fixture*.csv", "fixtures.csv", "*.xlsx"])
        if results:
            self.results_path.set(str(results))
        if fixtures:
            self.fixtures_path.set(str(fixtures))
        self.status_var.set(f"Auto-find complete | results={bool(results)} fixtures={bool(fixtures)}")
        messagebox.showinfo("Auto-find", f"Results: {results}\nFixtures: {fixtures}")

    def _prepare_results_df(self, path: str) -> pd.DataFrame:
        df = read_csv_any(path)
        df = filter_by_division(df, self.selected_div_code)
        return normalise_match_file(df, season=self.season_code_var.get().strip() or None)

    def _prepare_fixtures_df(self, path: str) -> pd.DataFrame:
        df = read_csv_any(path)
        df = filter_by_division(df, self.selected_div_code)
        return normalise_match_file(df, season=self.season_code_var.get().strip() or None)

    def _ensure_categories_file(self):
        p = Path(self.categories_path.get())
        p.parent.mkdir(parents=True, exist_ok=True)
        if not p.exists():
            p.write_text("{}", encoding="utf-8")

    def _load_categories_if_exists(self):
        self._ensure_categories_file()
        return load_categories(self.categories_path.get())

    def _all_teams_from_loaded(self):
        teams = set()
        for df in [self.results_df, self.fixtures_df]:
            if df is None or df.empty:
                continue
            for c in ["HomeTeam", "AwayTeam"]:
                if c in df.columns:
                    teams.update(df[c].dropna().astype(str).tolist())
        return sorted(teams)

    def _build_current_table(self) -> pd.DataFrame:
        if self.results_df is None or self.results_df.empty:
            return pd.DataFrame(columns=["Team","P","W","D","L","GF","GA","GD","Pts","Pos"])
        pred = self._predictor()
        as_of = (self.fixtures_df["Date"].min() if self.fixtures_df is not None and not self.fixtures_df.empty else pd.Timestamp.max)
        season = self.season_code_var.get().strip() or None
        return pred.build_table_before(self.results_df, pd.to_datetime(as_of), season=season)

    def _auto_seed_categories(self):
        table = self._build_current_table()
        if table.empty:
            return {}
        n = len(table)
        mapping = {}
        for _, row in table.iterrows():
            pos = int(row["Pos"])
            if n >= 18:
                # seven buckets so lower-table teams are not over-compressed
                if pos <= 2: cat = "A"
                elif pos <= 5: cat = "B"
                elif pos <= 8: cat = "C"
                elif pos <= 12: cat = "D"
                elif pos <= 15: cat = "E"
                elif pos <= 18: cat = "F"
                else: cat = "G"
            else:
                q = (pos - 1) / max(n, 1)
                if q < 0.10: cat = "A"
                elif q < 0.25: cat = "B"
                elif q < 0.40: cat = "C"
                elif q < 0.60: cat = "D"
                elif q < 0.78: cat = "E"
                elif q < 0.92: cat = "F"
                else: cat = "G"
            mapping[str(row["Team"])] = cat
        return mapping

    def _category_coverage_text(self, categories: dict[str, str]) -> str:
        teams = self._all_teams_from_loaded()
        if not teams:
            return "Categories: no teams loaded yet"
        matched = sum(1 for t in teams if t in categories and str(categories.get(t, "")).upper() in {"A","B","C","D","E","F","G"})
        defaulted = len(teams) - matched
        counts = {k: 0 for k in ["A", "B", "C", "D", "E", "F", "G"]}
        for t in teams:
            c = str(categories.get(t, "D")).upper()[:1]
            if c not in counts:
                c = "D"
            counts[c] += 1
        return f"Categories matched={matched}/{len(teams)} (defaulted={defaulted}) | A:{counts['A']} B:{counts['B']} C:{counts['C']} D:{counts['D']} E:{counts['E']} F:{counts['F']} G:{counts['G']}"

    def load_files(self):
        try:
            self._ensure_categories_file()
            if not self.results_path.get():
                raise ValueError("Results file path is empty. Use Download buttons or Browse.")
            fixtures_input_path = self.fixtures_path.get() or self.results_path.get()

            r_df = self._prepare_results_df(self.results_path.get())
            f_df = self._prepare_fixtures_df(fixtures_input_path)
            r_results, _ = split_results_fixtures(r_df)
            _, f_fixtures = split_results_fixtures(f_df)

            self.results_df = r_results.copy()
            self.fixtures_df = f_fixtures.copy()
            self.all_df = (
                pd.concat([r_df, f_df], ignore_index=True)
                .drop_duplicates(subset=["Date", "HomeTeam", "AwayTeam"], keep="last")
                .sort_values(["Date", "HomeTeam", "AwayTeam"])
                .reset_index(drop=True)
            )

            cats = self._manual_categories_with_seed()
            coverage = self._category_coverage_text(cats)
            table = self._build_current_table()
            preview = []
            preview.append(f"Country/League: {self.country_var.get()} / {self.league_display_var.get()} ({self.selected_div_code})")
            preview.append(f"Season code: {self.season_code_var.get().strip() or 'auto'}")
            preview.append(f"Results rows: {len(self.results_df)}")
            preview.append(f"Fixtures rows: {len(self.fixtures_df)}")
            preview.append(coverage)
            preview.append("")
            if not table.empty:
                preview.append("Current table snapshot (before next fixture date):")
                preview.append(table.head(10).to_string(index=False))
                preview.append("")
            preview.append("Results sample:")
            preview.append(self.results_df.head(10).to_string(index=False))
            preview.append("\nFixtures sample:")
            preview.append(self.fixtures_df.head(10).to_string(index=False))
            self.preview_text.delete("1.0", "end")
            self.preview_text.insert("end", "\n".join(preview))
            self.status_var.set(f"Loaded files OK | {coverage}")
            self.notebook.select(self.preview_text)
        except Exception as e:
            messagebox.showerror("Load failed", str(e))

    def _predictor(self):
        base = {"lookback": int(self.lookback_var.get()), "threshold": float(self.threshold_var.get())}
        if self.weight_profile:
            wp = dict(self.weight_profile)
            wp.update(base)
            cfg = PredictorConfig(**wp)
        else:
            cfg = PredictorConfig(**base)
        return MatchPredictor(cfg)

    def edit_categories(self):
        self._ensure_categories_file()
        if self.results_df is None and self.fixtures_df is None:
            self.load_files()
            if self.results_df is None and self.fixtures_df is None:
                messagebox.showinfo("Categories", "Load files first so I can list teams.")
                return

        existing = self._load_categories_if_exists()
        teams = self._all_teams_from_loaded()
        table = self._build_current_table()
        # Prefer league-position order, then append any extras alphabetically
        if table is not None and not table.empty and "Team" in table.columns:
            ordered = [str(t) for t in table.sort_values("Pos")["Team"].tolist()]
            extras = [t for t in teams if t not in set(ordered)]
            teams = ordered + sorted(extras)
        seeded = self._auto_seed_categories()

        win = tk.Toplevel(self)
        self.category_editor_win = win
        win.title("Team Categories (A-G)")
        win.geometry("860x680")

        top = ttk.Frame(win, padding=8)
        top.pack(fill="x")
        coverage_lbl = ttk.Label(top, text=self._category_coverage_text(existing))
        coverage_lbl.pack(side="left")
        ttk.Button(top, text="Auto-seed from table bands", command=lambda: self._apply_seed_to_editor(seeded, coverage_lbl)).pack(side="right", padx=4)
        ttk.Button(top, text="Load existing JSON", command=lambda: self._apply_seed_to_editor(existing, coverage_lbl)).pack(side="right", padx=4)

        cols = ["Pos", "Team", "P", "GD", "Pts", "Category"]
        tree_frame = ttk.Frame(win)
        tree_frame.pack(fill="both", expand=True, padx=8, pady=8)
        canvas = tk.Canvas(tree_frame)
        scrollbar = ttk.Scrollbar(tree_frame, orient="vertical", command=canvas.yview)
        inner = ttk.Frame(canvas)
        inner.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=inner, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        for j, c in enumerate(cols):
            ttk.Label(inner, text=c, font=(None, 9, "bold")).grid(row=0, column=j, sticky="w", padx=4, pady=2)

        table_map = {str(r.Team): r for _, r in table.iterrows()} if not table.empty else {}
        self.category_row_vars = {}
        source_map = dict(seeded)
        source_map.update({k: v for k, v in existing.items() if v})  # existing overrides seed

        for i, team in enumerate(teams, start=1):
            r = table_map.get(team)
            ttk.Label(inner, text="" if r is None else int(r.Pos)).grid(row=i, column=0, sticky="e", padx=4, pady=2)
            ttk.Label(inner, text=team).grid(row=i, column=1, sticky="w", padx=4, pady=2)
            ttk.Label(inner, text="" if r is None else int(r.P)).grid(row=i, column=2, sticky="e", padx=4, pady=2)
            ttk.Label(inner, text="" if r is None else int(r.GD)).grid(row=i, column=3, sticky="e", padx=4, pady=2)
            ttk.Label(inner, text="" if r is None else int(r.Pts)).grid(row=i, column=4, sticky="e", padx=4, pady=2)
            v = tk.StringVar(value=str(source_map.get(team, "D")).upper()[:1] if source_map.get(team) else "D")
            cb = ttk.Combobox(inner, textvariable=v, values=["A", "B", "C", "D", "E", "F", "G"], width=4, state="readonly")
            cb.grid(row=i, column=5, sticky="w", padx=4, pady=2)
            cb.bind("<<ComboboxSelected>>", lambda e: coverage_lbl.config(text=self._category_coverage_text(self._editor_mapping())))
            self.category_row_vars[team] = v

        btns = ttk.Frame(win, padding=8)
        btns.pack(fill="x")
        ttk.Button(btns, text="Save Categories", command=lambda: self._save_category_editor(coverage_lbl)).pack(side="right")
        ttk.Button(btns, text="Close", command=win.destroy).pack(side="right", padx=6)

    def _editor_mapping(self):
        mapping = {}
        for team, var in self.category_row_vars.items():
            c = str(var.get()).upper()[:1] or "D"
            if c not in {"A","B","C","D","E","F","G"}:
                c = "D"
            mapping[team] = c
        return mapping

    def _apply_seed_to_editor(self, seed_map, coverage_lbl):
        if not self.category_row_vars:
            return
        for team, var in self.category_row_vars.items():
            var.set(str(seed_map.get(team, "D")).upper()[:1])
        coverage_lbl.config(text=self._category_coverage_text(self._editor_mapping()))

    def _save_category_editor(self, coverage_lbl=None):
        mapping = self._editor_mapping()
        save_categories(self.categories_path.get(), mapping)
        if coverage_lbl is not None:
            coverage_lbl.config(text=self._category_coverage_text(mapping))
        self.status_var.set(f"Saved {len(mapping)} team categories")
        messagebox.showinfo("Saved", f"Saved {len(mapping)} teams to {self.categories_path.get()}")

    def run_backtest(self):
        if self.results_df is None:
            self.load_files()
            if self.results_df is None:
                return
        pred = self._predictor()
        cats = self._manual_categories_with_seed()
        max_lb = max(3, int(self.max_lookback_var.get()))
        bt = pred.backtest(self.results_df, lookbacks=range(3, max_lb + 1), thresholds=range(1, 11), manual_categories=cats)
        if bt is None or bt.empty:
            self.backtest_df = pd.DataFrame({"message": ["No backtest rows produced. Check data / dates / result columns."]})
            self._show_df_in_tree(self.backtest_tree, self.backtest_df)
            self.notebook.select(self.backtest_frame)
            return
        # composite ranking to avoid tiny sample rows dominating
        bt = bt.copy()
        min_games = max(0, int(self.min_games_var.get()))
        bt["meets_min_games"] = bt["games"] >= min_games
        bt["sample_weight"] = (bt["games"] / bt["games"].max()).round(3)
        bt["rank_score"] = (bt["accuracy_pct"] * (0.35 + 0.65 * bt["sample_weight"])).round(2)
        bt = bt.sort_values(["meets_min_games", "rank_score", "accuracy_pct", "games"], ascending=[False, False, False, False]).reset_index(drop=True)
        self.backtest_df = bt
        self._show_df_in_tree(self.backtest_tree, bt)
        top = bt.iloc[0]
        self.status_var.set(
            f"Backtest complete | top row lookback={int(top['lookback'])} th={top['threshold']} acc={top['accuracy_pct']}% games={int(top['games'])} (min games is GLOBAL backtest sample, not per-team)"
        )
        self.notebook.select(self.backtest_frame)

    def run_predictions(self):
        if self.results_df is None or self.fixtures_df is None:
            self.load_files()
            if self.results_df is None or self.fixtures_df is None:
                return
        pred = self._predictor()
        cats = self._manual_categories_with_seed()
        coverage = self._category_coverage_text(cats)
        out = pred.predict_fixtures(self.fixtures_df, self.results_df, manual_categories=cats)
        # add visible categories being used (from manual if present else default C fallback shown explicitly)
        if not out.empty:
            out = out.copy()
            out.insert(3, "HomeCategory", out["HomeTeam"].map(lambda t: str(cats.get(str(t), "D")).upper()[:1]))
            out.insert(4, "AwayCategory", out["AwayTeam"].map(lambda t: str(cats.get(str(t), "D")).upper()[:1]))
        self.predictions_df = out
        if self.predictions_df.empty:
            self._show_df_in_tree(self.pred_tree, pd.DataFrame({"message": ["No fixtures to predict."]}))
        else:
            self._show_df_in_tree(self.pred_tree, self.predictions_df)
        self.status_var.set(f"Predictions complete | {coverage}")
        self.notebook.select(self.pred_frame)

    def _parse_season_list(self, txt: str) -> list[str]:
        parts = [p.strip() for p in str(txt or "").replace(";",",").split(",")]
        return [p for p in parts if p]

    def _manual_categories_with_seed(self) -> dict[str,str]:
        cats = self._load_categories_if_exists()
        teams = self._all_teams_from_loaded()
        # if categories missing or mostly default, auto-seed from current table and merge
        matched = sum(1 for t in teams if str(cats.get(t, "")).upper()[:1] in {"A","B","C","D","E","F","G"}) if teams else 0
        if not teams:
            return cats
        if matched == 0 or len(set(str(v).upper()[:1] for v in cats.values() if v)) <= 1:
            seeded = self._auto_seed_categories()
            if seeded:
                merged = dict(seeded)
                # existing non-empty explicit values override seed
                for k, v in cats.items():
                    c = str(v).upper()[:1]
                    if c in {"A","B","C","D","E","F","G"}:
                        merged[k] = c
                cats = merged
                # persist so user doesn't silently stay all-C
                save_categories(self.categories_path.get(), cats)
        return cats

    def run_weight_tuning(self):
        if self.results_df is None:
            self.load_files()
            if self.results_df is None:
                return
        try:
            cats = self._manual_categories_with_seed()
            train = self._parse_season_list(self.tune_train_seasons_var.get())
            valid = self._parse_season_list(self.tune_valid_seasons_var.get())
            if not train:
                season = self.season_code_var.get().strip()
                train = [season] if season else []
            tuner = WeightTuner(self.results_df)
            report = tuner.tune(
                manual_categories=cats,
                train_seasons=train or None,
                valid_seasons=valid or None,
                n_candidates=int(self.tune_candidates_var.get()),
                lookbacks=range(3, max(3, int(self.max_lookback_var.get())) + 1),
                thresholds=range(1, 11),
                min_games_train=int(self.min_games_var.get()),
            )
            self.tuning_df = report["leaderboard"].copy()
            self._show_df_in_tree(self.tuning_tree, self.tuning_df)
            self.weight_profile = report["best_config"]
            self.lookback_var.set(int(self.weight_profile.get("lookback", self.lookback_var.get())))
            self.threshold_var.set(float(self.weight_profile.get("threshold", self.threshold_var.get())))
            vtxt = ""
            if report.get("validation"):
                v = report["validation"]
                vtxt = f" | valid acc={v['accuracy_pct']:.2f}% games={v['games']}"
            top = self.tuning_df.iloc[0] if not self.tuning_df.empty else None
            self.status_var.set(f"Weight tuning complete | candidates={int(self.tune_candidates_var.get())} | top acc={float(top['accuracy_pct']):.2f}% games={int(top['games'])}{vtxt}")
            self.notebook.select(self.tuning_frame)
        except Exception as e:
            messagebox.showerror("Weight tuning failed", str(e))

    def _on_tuning_double_click(self, _event=None):
        item = self.tuning_tree.focus()
        if not item:
            return
        vals = self.tuning_tree.item(item, "values")
        cols = list(self.tuning_tree["columns"])
        if not vals:
            return
        row = dict(zip(cols, vals))
        try:
            cid = int(float(row.get("candidate_id")))
            if self.tuning_df is None or self.tuning_df.empty:
                return
            r = self.tuning_df[self.tuning_df["candidate_id"].astype(int) == cid]
            if r.empty:
                return
            self.lookback_var.set(int(float(row["lookback"])))
            self.threshold_var.set(float(row["threshold"]))
            # note: full weight profile already applied from best_config; row double-click just applies params
            self.status_var.set(f"Applied tuning row candidate={cid} lookback={self.lookback_var.get()} threshold={self.threshold_var.get()}")
        except Exception:
            return

    def save_tuned_profile(self):
        if not self.weight_profile:
            messagebox.showinfo("Save profile", "No tuned profile yet. Run weight tuning first.")
            return
        p = filedialog.asksaveasfilename(defaultextension=".json", filetypes=[("JSON", "*.json")], initialfile=f"{self.selected_div_code.lower()}_weight_profile.json")
        if not p:
            return
        data = dict(self.weight_profile)
        data["profile_name"] = f"{self.selected_div_code}_tuned"
        data["country"] = self.country_var.get()
        data["league"] = self.league_display_var.get()
        Path(p).write_text(json.dumps(data, indent=2), encoding="utf-8")
        self.status_var.set(f"Saved tuned profile to {p}")
        messagebox.showinfo("Saved", p)


    def run_weekly_performance(self):
        if self.results_df is None:
            self.load_files()
            if self.results_df is None:
                return
        pred = self._predictor()
        cats = self._manual_categories_with_seed()
        max_lb = max(3, int(self.max_lookback_var.get()))
        min_week_games = max(1, int(self.min_week_games_var.get()))
        summary, details = pred.weekly_performance_grid(
            self.results_df,
            lookbacks=range(3, max_lb + 1),
            thresholds=range(1, 11),
            manual_categories=cats,
            min_week_games=min_week_games,
        )
        if summary is None or summary.empty:
            self.weekly_summary_df = pd.DataFrame({"message": ["No weekly performance rows produced."]})
            self.weekly_details_df = pd.DataFrame()
            self._show_df_in_tree(self.weekly_tree, self.weekly_summary_df)
            self.notebook.select(self.weekly_frame)
            return
        summary = summary.copy()
        min_games = max(0, int(self.min_games_var.get()))
        summary["meets_min_games"] = summary["games"] >= min_games
        summary["weekly_spike_score"] = (
            summary["perfect_weeks_100"] * 10
            + summary["weeks_ge90"] * 3
            + summary["weeks_ge80"] * 1
            + summary["accuracy_pct"] / 100.0
        ).round(3)
        summary = summary.sort_values(
            ["meets_min_games", "weekly_spike_score", "perfect_weeks_100", "weeks_ge90", "accuracy_pct", "games"],
            ascending=[False, False, False, False, False, False],
        ).reset_index(drop=True)
        self.weekly_summary_df = summary
        self.weekly_details_df = details.copy() if details is not None else pd.DataFrame()
        self._show_df_in_tree(self.weekly_tree, self.weekly_summary_df)
        top = self.weekly_summary_df.iloc[0]
        self.status_var.set(
            f"Weekly performance complete | top lb={int(top['lookback'])} th={top['threshold']} perfect={int(top['perfect_weeks_100'])} 90%+={int(top['weeks_ge90'])} overall={float(top['accuracy_pct']):.2f}%"
        )
        self.notebook.select(self.weekly_frame)

    def _on_weekly_summary_double_click(self, _event=None):
        item = self.weekly_tree.focus()
        if not item:
            return
        vals = self.weekly_tree.item(item, "values")
        cols = list(self.weekly_tree["columns"])
        if not vals or "lookback" not in cols or "threshold" not in cols:
            return
        row = dict(zip(cols, vals))
        try:
            lb = int(float(row["lookback"]))
            th = float(row["threshold"])
            self.lookback_var.set(lb)
            self.threshold_var.set(th)
        except Exception:
            return
        if self.weekly_details_df is None or self.weekly_details_df.empty:
            self.status_var.set(f"Applied weekly row: lookback={self.lookback_var.get()} threshold={self.threshold_var.get()}")
            return
        d = self.weekly_details_df.copy()
        try:
            d = d[(d["lookback"].astype(int) == lb) & (d["threshold"].astype(float) == th)].copy()
        except Exception:
            pass
        if d is not None and not d.empty:
            d = d.sort_values(["Season", "week_start"]).reset_index(drop=True)
            self._show_df_in_tree(self.weekly_detail_tree, d)
            self.weekly_detail_label_var.set(
                f"Weekly detail for lookback={lb}, threshold={th} | perfect weeks={int((d['accuracy_pct']>=100).sum())} | 90%+ weeks={int((d['accuracy_pct']>=90).sum())}"
            )
            self.notebook.select(self.weekly_detail_frame)
        self.status_var.set(f"Applied weekly row + loaded weekly detail: lookback={lb} threshold={th}")

    def export_predictions(self):
        if self.predictions_df is None or self.predictions_df.empty:
            messagebox.showinfo("Export", "No predictions yet. Run predictions first.")
            return
        p = filedialog.asksaveasfilename(defaultextension=".csv", filetypes=[("CSV", "*.csv")], initialfile="predictions.csv")
        if not p:
            return
        self.predictions_df.to_csv(p, index=False)
        self.status_var.set(f"Exported predictions to {p}")
        messagebox.showinfo("Exported", p)


def main():
    app = PredictorGUI()
    app.mainloop()


if __name__ == "__main__":
    main()
