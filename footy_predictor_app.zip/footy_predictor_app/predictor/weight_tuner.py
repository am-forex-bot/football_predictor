from __future__ import annotations
import random
from dataclasses import asdict
from typing import Optional
import pandas as pd

from .engine import MatchPredictor
from .models import PredictorConfig

TIERS = ["T1","T2","T3","T4","T5","T6","T7"]
VENUES = ["Home","Away"]


def _sample_monotonic_desc(rng: random.Random, hi_range=(5,10), min_step=0.5, max_step=2.5):
    vals = []
    cur = rng.uniform(*hi_range)
    vals.append(round(cur,2))
    for _ in range(len(TIERS)-1):
        cur = cur - rng.uniform(min_step, max_step)
        vals.append(round(cur,2))
    return vals


def _sample_monotonic_mixed(rng: random.Random, start_range=(2,4), end_range=(-4,-1)):
    start = rng.uniform(*start_range)
    end = rng.uniform(*end_range)
    den = max(1, len(TIERS)-1)
    vals = [round(start + (end-start)*(i/den),2) for i in range(len(TIERS))]
    # small jitter but keep descending overall
    vals = [v + rng.uniform(-0.4,0.4) for v in vals]
    for i in range(1, len(TIERS)):
        if vals[i] > vals[i-1]-0.1:
            vals[i] = vals[i-1]-rng.uniform(0.3,1.2)
    return [round(v,2) for v in vals]


def random_weight_config(rng: random.Random, base_cfg: PredictorConfig) -> PredictorConfig:
    cfgd = asdict(base_cfg)
    win_home = _sample_monotonic_desc(rng, hi_range=(5.5,8.5))
    win_away = [round(v + rng.uniform(0.3,1.6),2) for v in win_home]
    draw_home = _sample_monotonic_desc(rng, hi_range=(2.5,6.0), min_step=0.4, max_step=1.5)
    draw_away = [round(v + rng.uniform(0.1,1.2),2) for v in draw_home]
    loss_home = _sample_monotonic_mixed(rng, start_range=(1.0,3.0), end_range=(-4.5,-1.5))
    loss_away = [round(v + rng.uniform(0.2,1.2),2) for v in loss_home]
    cfgd["win_weights"] = {"Home": dict(zip(TIERS, win_home)), "Away": dict(zip(TIERS, win_away))}
    cfgd["draw_weights"] = {"Home": dict(zip(TIERS, draw_home)), "Away": dict(zip(TIERS, draw_away))}
    cfgd["loss_close_weights"] = {"Home": dict(zip(TIERS, loss_home)), "Away": dict(zip(TIERS, loss_away))}
    cfgd["loss_heavy_penalty"] = round(rng.uniform(-2.5,-0.3),2)
    return PredictorConfig(**cfgd)


class WeightTuner:
    def __init__(self, results_df: pd.DataFrame, seed: int = 42):
        self.results_df = results_df.copy()
        self.rng = random.Random(seed)

    def _subset_seasons(self, seasons: Optional[list[str]]) -> pd.DataFrame:
        if not seasons:
            return self.results_df.copy()
        if "Season" not in self.results_df.columns:
            return self.results_df.copy()
        ss = {str(s) for s in seasons}
        return self.results_df[self.results_df["Season"].astype(str).isin(ss)].copy()

    def tune(
        self,
        manual_categories: Optional[dict[str,str]] = None,
        train_seasons: Optional[list[str]] = None,
        valid_seasons: Optional[list[str]] = None,
        n_candidates: int = 120,
        lookbacks = range(3,11),
        thresholds = range(1,11),
        min_games_train: int = 50,
        min_games_valid: int = 20,
        no_bet_band: float = 0.0,
    ) -> dict:
        train_df = self._subset_seasons(train_seasons)
        valid_df = self._subset_seasons(valid_seasons) if valid_seasons else pd.DataFrame()
        if train_df.empty:
            raise ValueError("Training data is empty after season filtering.")

        base_cfg = PredictorConfig(no_bet_band=float(no_bet_band))
        leaderboard = []
        best_train = None
        best_id = None
        best_cfg = None

        for cid in range(1, n_candidates + 1):
            cfg = random_weight_config(self.rng, base_cfg)
            pred = MatchPredictor(cfg)
            bt = pred.backtest(train_df, lookbacks=lookbacks, thresholds=thresholds, manual_categories=manual_categories)
            if bt.empty:
                continue
            bt = bt.copy()
            bt["meets_min_games"] = bt["games"] >= int(min_games_train)
            gmax = max(1, int(bt["games"].max()))
            bt["sample_weight"] = bt["games"] / gmax
            bt["rank_score"] = bt["accuracy_pct"] * (0.35 + 0.65*bt["sample_weight"])
            bt = bt.sort_values(["meets_min_games","rank_score","accuracy_pct","games"], ascending=[False,False,False,False]).reset_index(drop=True)
            top = bt.iloc[0].to_dict()
            row = {
                "candidate_id": cid,
                "lookback": int(top["lookback"]),
                "threshold": float(top["threshold"]),
                "games": int(top["games"]),
                "accuracy_pct": float(top["accuracy_pct"]),
                "rank_score": round(float(top["rank_score"]),2),
                "meets_min_games": bool(top["meets_min_games"]),
                "loss_heavy_penalty": cfg.loss_heavy_penalty,
                "cfg": cfg,
            }
            leaderboard.append(row)
            if best_train is None or (row["meets_min_games"], row["rank_score"], row["accuracy_pct"], row["games"]) > (
                best_train["meets_min_games"], best_train["rank_score"], best_train["accuracy_pct"], best_train["games"]
            ):
                best_train = row
                best_id = cid
                best_cfg = cfg

        if not leaderboard:
            raise RuntimeError("No tuning candidates produced results.")

        lb_df = pd.DataFrame([{k:v for k,v in r.items() if k != "cfg"} for r in leaderboard]).sort_values(
            ["meets_min_games","rank_score","accuracy_pct","games"], ascending=[False,False,False,False]
        ).reset_index(drop=True)

        valid_summary = None
        if best_cfg is not None and valid_df is not None and not valid_df.empty:
            chosen = lb_df.iloc[0]
            cfgd = asdict(best_cfg)
            cfgd["lookback"] = int(chosen["lookback"])
            cfgd["threshold"] = float(chosen["threshold"])
            predv = MatchPredictor(PredictorConfig(**cfgd))
            btv = predv.backtest(valid_df, lookbacks=[int(chosen["lookback"])], thresholds=[int(float(chosen["threshold"]))], manual_categories=manual_categories)
            if not btv.empty:
                rr = btv.iloc[0].to_dict()
                valid_summary = {
                    "games": int(rr.get("games",0)),
                    "accuracy_pct": float(rr.get("accuracy_pct",0.0)),
                    "draw_accuracy_pct": float(rr.get("draw_accuracy_pct",0.0)),
                    "meets_min_games": int(rr.get("games",0)) >= int(min_games_valid),
                }

        top_cfg_row = next(r for r in leaderboard if r["candidate_id"] == int(lb_df.iloc[0]["candidate_id"]))
        top_cfg = top_cfg_row["cfg"]
        best_config = asdict(top_cfg)
        best_config["lookback"] = int(lb_df.iloc[0]["lookback"])
        best_config["threshold"] = float(lb_df.iloc[0]["threshold"])
        return {
            "leaderboard": lb_df,
            "best_config": best_config,
            "validation": valid_summary,
        }
