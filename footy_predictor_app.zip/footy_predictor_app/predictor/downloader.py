from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from pathlib import Path
from urllib.request import urlopen

# Country -> leagues (football-data.co.uk codes)
COUNTRY_LEAGUES = {
    "England": [
        ("Premier League", "E0"),
        ("Championship", "E1"),
        ("League One", "E2"),
        ("League Two", "E3"),
    ],
    "Spain": [
        ("La Liga", "SP1"),
        ("Segunda", "SP2"),
    ],
    "Italy": [
        ("Serie A", "I1"),
        ("Serie B", "I2"),
    ],
    "Germany": [
        ("Bundesliga", "D1"),
        ("2. Bundesliga", "D2"),
    ],
    "France": [
        ("Ligue 1", "F1"),
        ("Ligue 2", "F2"),
    ],
    "Netherlands": [
        ("Eredivisie", "N1"),
        ("Eerste Divisie", "N2"),
    ],
    "Portugal": [
        ("Primeira Liga", "P1"),
        ("Liga Portugal 2", "P2"),
    ],
}

# Backwards-compatible flattened mapping used elsewhere
LEAGUE_CODES = {
    f"{league} ({country[:3].upper()})": code
    for country, leagues in COUNTRY_LEAGUES.items()
    for league, code in leagues
}


@dataclass
class DownloadedFiles:
    results_path: Path
    fixtures_path: Path


def default_season_code(today: date | None = None) -> str:
    """football-data.co.uk style season code e.g. 2526 for 2025/26."""
    today = today or date.today()
    start_year = today.year if today.month >= 7 else today.year - 1
    return f"{start_year % 100:02d}{(start_year + 1) % 100:02d}"


def football_data_urls(league_code: str, season_code: str | None = None) -> tuple[str, str]:
    season_code = season_code or default_season_code()
    results_url = f"https://www.football-data.co.uk/mmz4281/{season_code}/{league_code}.csv"
    fixtures_url = "https://www.football-data.co.uk/fixtures.csv"
    return results_url, fixtures_url


def _download(url: str, target: Path) -> Path:
    target.parent.mkdir(parents=True, exist_ok=True)
    with urlopen(url, timeout=30) as resp:
        data = resp.read()
    target.write_bytes(data)
    return target


def download_football_data_files(download_dir: str | Path, league_code: str, season_code: str | None = None) -> DownloadedFiles:
    d = Path(download_dir)
    season_code = season_code or default_season_code()
    results_url, fixtures_url = football_data_urls(league_code, season_code)
    results_path = d / f"{league_code}_{season_code}_results.csv"
    fixtures_path = d / "football-data_fixtures.csv"
    _download(results_url, results_path)
    _download(fixtures_url, fixtures_path)
    return DownloadedFiles(results_path=results_path, fixtures_path=fixtures_path)
