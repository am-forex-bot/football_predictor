from __future__ import annotations
import itertools
from dataclasses import asdict
from typing import Dict, List, Optional, Tuple
import pandas as pd
from .models import PredictorConfig

CATEGORY_TO_TIER = {"A":"T1","B":"T2","C":"T3","D":"T4","E":"T5","F":"T6","G":"T7"}


class MatchPredictor:
    def __init__(self, config: Optional[PredictorConfig] = None):
        self.config = config or PredictorConfig()

    def build_table_before(self, results: pd.DataFrame, as_of_date: pd.Timestamp, season: Optional[str]=None) -> pd.DataFrame:
        r = results[results["Date"] < as_of_date].copy()
        if season is not None and "Season" in r.columns:
            r = r[r["Season"].astype(str) == str(season)]
        rows = []
        for _, m in r.iterrows():
            rows.append((m["HomeTeam"], m["AwayTeam"], int(m["FTHG"]), int(m["FTAG"])))
            rows.append((m["AwayTeam"], m["HomeTeam"], int(m["FTAG"]), int(m["FTHG"])))
        if not rows:
            return pd.DataFrame(columns=["Team","P","W","D","L","GF","GA","GD","Pts","Pos"])
        df = pd.DataFrame(rows, columns=["Team","Opp","GF","GA"])
        df["W"] = (df.GF > df.GA).astype(int)
        df["D"] = (df.GF == df.GA).astype(int)
        df["L"] = (df.GF < df.GA).astype(int)
        df["Pts"] = 3*df.W + df.D
        tbl = df.groupby("Team", as_index=False).agg(P=("Team","size"),W=("W","sum"),D=("D","sum"),L=("L","sum"),GF=("GF","sum"),GA=("GA","sum"),Pts=("Pts","sum"))
        tbl["GD"] = tbl["GF"] - tbl["GA"]
        tbl = tbl.sort_values(["Pts","GD","GF","Team"], ascending=[False,False,False,True]).reset_index(drop=True)
        tbl["Pos"] = tbl.index + 1
        return tbl[["Team","P","W","D","L","GF","GA","GD","Pts","Pos"]]

    def infer_categories_from_table(self, table: pd.DataFrame) -> Dict[str,str]:
        # default heuristic buckets by rank quintiles (can be replaced by manual GUI categories)
        if table.empty:
            return {}
        n = len(table)
        mapping = {}
        for _, row in table.iterrows():
            p = int(row["Pos"])
            q = (p-1) / max(n,1)
            if q < 0.12: c="A"
            elif q < 0.32: c="B"
            elif q < 0.55: c="C"
            elif q < 0.78: c="D"
            elif q < 0.90: c="E"
            elif q < 0.97: c="F"
            else: c="G"
            mapping[str(row["Team"])] = c
        return mapping

    def _score_match(self, result: str, venue: str, opp_category: str, gf: int, ga: int) -> float:
        tier = CATEGORY_TO_TIER.get(str(opp_category).upper()[:1], "T4")
        cfg = self.config
        if result == "W":
            return cfg.win_weights[venue][tier]
        if result == "D":
            return cfg.draw_weights[venue][tier]
        base = cfg.loss_close_weights[venue][tier]
        gd = gf - ga
        if gd <= -2:
            base += cfg.loss_heavy_penalty
        return base

    def _team_form_score(self, team: str, venue: str, before_date: pd.Timestamp, results: pd.DataFrame,
                         category_map: Dict[str,str], lookback: int, season: Optional[str]) -> float:
        r = results[results["Date"] < before_date].copy()
        if season is not None and "Season" in r.columns:
            r = r[r["Season"].astype(str) == str(season)]
        if venue == "Home":
            rr = r[r["HomeTeam"] == team].sort_values("Date").tail(lookback)
            vals = []
            for _, m in rr.iterrows():
                opp = m["AwayTeam"]
                cat = category_map.get(opp, "D")
                res = "W" if m["FTR"] == "H" else ("D" if m["FTR"] == "D" else "L")
                vals.append(self._score_match(res, "Home", cat, int(m["FTHG"]), int(m["FTAG"])))
            return float(sum(vals))
        rr = r[r["AwayTeam"] == team].sort_values("Date").tail(lookback)
        vals = []
        for _, m in rr.iterrows():
            opp = m["HomeTeam"]
            cat = category_map.get(opp, "D")
            res = "W" if m["FTR"] == "A" else ("D" if m["FTR"] == "D" else "L")
            vals.append(self._score_match(res, "Away", cat, int(m["FTAG"]), int(m["FTHG"])))
        return float(sum(vals))

    def predict_fixture_row(self, fixture: pd.Series, results: pd.DataFrame,
                            manual_categories: Optional[Dict[str,str]] = None) -> Dict:
        date = pd.to_datetime(fixture["Date"])
        season = str(fixture.get("Season")) if pd.notna(fixture.get("Season")) else None
        table = self.build_table_before(results, date, season=season)
        cat_map = (manual_categories or {}) if self.config.use_manual_categories else {}
        if not cat_map:
            cat_map = self.infer_categories_from_table(table)
        hs = self._team_form_score(str(fixture["HomeTeam"]), "Home", date, results, cat_map, self.config.lookback, season)
        as_ = self._team_form_score(str(fixture["AwayTeam"]), "Away", date, results, cat_map, self.config.lookback, season)
        diff = hs - as_
        if abs(diff) <= self.config.no_bet_band:
            pred = "X"  # no edge / too close
        elif diff > self.config.threshold:
            pred = "H"
        elif diff < -self.config.threshold:
            pred = "A"
        else:
            pred = "D"
        return {
            "Date": date,
            "HomeTeam": fixture["HomeTeam"],
            "AwayTeam": fixture["AwayTeam"],
            "HomeScore": round(hs,2),
            "AwayScore": round(as_,2),
            "ScoreDiff": round(diff,2),
            "Prediction": pred,
            "Lookback": self.config.lookback,
            "Threshold": self.config.threshold,
        }

    def predict_fixtures(self, fixtures: pd.DataFrame, results: pd.DataFrame, manual_categories: Optional[Dict[str,str]]=None) -> pd.DataFrame:
        rows = [self.predict_fixture_row(row, results, manual_categories) for _, row in fixtures.sort_values(["Date","HomeTeam"]).iterrows()]
        return pd.DataFrame(rows)



    def _week_start(self, dt: pd.Timestamp) -> pd.Timestamp:
        d = pd.to_datetime(dt).normalize()
        return d - pd.Timedelta(days=int(d.weekday()))

    def weekly_performance_grid(self, results: pd.DataFrame, lookbacks=range(3,11), thresholds=range(1,11),
                                manual_categories: Optional[Dict[str,str]]=None, min_week_games: int = 1) -> Tuple[pd.DataFrame, pd.DataFrame]:
        completed = results.dropna(subset=["FTHG","FTAG","FTR"]).sort_values(["Date","HomeTeam","AwayTeam"]).reset_index(drop=True)
        summary_rows = []
        detail_rows = []
        if completed.empty:
            return pd.DataFrame(), pd.DataFrame()
        for lb, th in itertools.product(lookbacks, thresholds):
            cfg_old = self.config
            self.config = PredictorConfig(**{**asdict(cfg_old), "lookback": int(lb), "threshold": float(th)})
            combo_rows = []
            for _, row in completed.iterrows():
                date = pd.to_datetime(row["Date"])
                season = str(row.get("Season")) if pd.notna(row.get("Season")) else None
                prior = completed[(completed["Date"] < date)]
                if season is not None and "Season" in prior.columns:
                    prior = prior[prior["Season"].astype(str) == season]
                h_count = (prior["HomeTeam"] == row["HomeTeam"]).sum()
                a_count = (prior["AwayTeam"] == row["AwayTeam"]).sum()
                if h_count < lb or a_count < lb:
                    continue
                pred = self.predict_fixture_row(row, completed, manual_categories)["Prediction"]
                if pred == "X":
                    continue
                actual = str(row["FTR"])
                p = "D" if pred == "D" else pred
                ws = self._week_start(date)
                combo_rows.append({
                    "lookback": int(lb), "threshold": float(th), "Season": season or "", "Date": date,
                    "week_start": ws, "week_end": ws + pd.Timedelta(days=6),
                    "HomeTeam": row["HomeTeam"], "AwayTeam": row["AwayTeam"],
                    "pred": p, "actual": actual, "correct": int(p == actual)
                })
            if combo_rows:
                cdf = pd.DataFrame(combo_rows)
                w = cdf.groupby(["lookback","threshold","Season","week_start","week_end"], as_index=False).agg(
                    games=("correct","size"), correct=("correct","sum")
                )
                w["accuracy_pct"] = (w["correct"] / w["games"] * 100).round(2)
                w["perfect_week"] = (w["accuracy_pct"] >= 100).astype(int)
                w["ge90_week"] = (w["accuracy_pct"] >= 90).astype(int)
                w["ge80_week"] = (w["accuracy_pct"] >= 80).astype(int)
                w["ge70_week"] = (w["accuracy_pct"] >= 70).astype(int)
                w["perfect_week_min_games"] = ((w["accuracy_pct"] >= 100) & (w["games"] >= max(1, int(min_week_games)))).astype(int)
                detail_rows.append(w.copy())

                # combine-level summary
                games_total = int(w["games"].sum())
                correct_total = int(w["correct"].sum())
                acc_total = round((correct_total / games_total * 100), 2) if games_total else 0.0
                summary_rows.append({
                    "lookback": int(lb),
                    "threshold": float(th),
                    "games": games_total,
                    "accuracy_pct": acc_total,
                    "weeks_tested": int(len(w)),
                    "perfect_weeks_100": int(w["perfect_week"].sum()),
                    f"perfect_weeks_100_min{max(1, int(min_week_games))}g": int(w["perfect_week_min_games"].sum()),
                    "weeks_ge90": int(w["ge90_week"].sum()),
                    "weeks_ge80": int(w["ge80_week"].sum()),
                    "weeks_ge70": int(w["ge70_week"].sum()),
                    "best_week_acc": float(w["accuracy_pct"].max()),
                    "avg_weekly_acc": round(float(w["accuracy_pct"].mean()), 2),
                    "median_weekly_acc": round(float(w["accuracy_pct"].median()), 2),
                    "worst_week_acc": float(w["accuracy_pct"].min()),
                    "max_games_in_week": int(w["games"].max()),
                    "min_games_in_week": int(w["games"].min()),
                })
            else:
                summary_rows.append({
                    "lookback": int(lb), "threshold": float(th), "games": 0, "accuracy_pct": 0.0, "weeks_tested": 0,
                    "perfect_weeks_100": 0, f"perfect_weeks_100_min{max(1, int(min_week_games))}g": 0,
                    "weeks_ge90": 0, "weeks_ge80": 0, "weeks_ge70": 0,
                    "best_week_acc": 0.0, "avg_weekly_acc": 0.0, "median_weekly_acc": 0.0, "worst_week_acc": 0.0,
                    "max_games_in_week": 0, "min_games_in_week": 0,
                })
            self.config = cfg_old
        summary_df = pd.DataFrame(summary_rows)
        if not summary_df.empty:
            summary_df = summary_df.sort_values(["perfect_weeks_100", "weeks_ge90", "weeks_ge80", "accuracy_pct", "games"],
                                                ascending=[False, False, False, False, False]).reset_index(drop=True)
        details_df = pd.concat(detail_rows, ignore_index=True) if detail_rows else pd.DataFrame()
        return summary_df, details_df

    def backtest(self, results: pd.DataFrame, lookbacks=range(3,11), thresholds=range(1,11), manual_categories: Optional[Dict[str,str]]=None) -> pd.DataFrame:
        completed = results.dropna(subset=["FTHG","FTAG","FTR"]).sort_values(["Date","HomeTeam","AwayTeam"]).reset_index(drop=True)
        out = []
        for lb, th in itertools.product(lookbacks, thresholds):
            cfg_old = self.config
            self.config = PredictorConfig(**{**asdict(cfg_old), "lookback": int(lb), "threshold": float(th)})
            correct = total = draws_pred = draws_correct = 0
            for _, row in completed.iterrows():
                # skip if not enough same-venue history in same season
                date = row["Date"]
                season = str(row.get("Season")) if pd.notna(row.get("Season")) else None
                prior = completed[(completed["Date"] < date)]
                if season is not None and "Season" in prior.columns:
                    prior = prior[prior["Season"].astype(str) == season]
                h_count = (prior["HomeTeam"] == row["HomeTeam"]).sum()
                a_count = (prior["AwayTeam"] == row["AwayTeam"]).sum()
                if h_count < lb or a_count < lb:
                    continue
                pred = self.predict_fixture_row(row, completed, manual_categories)["Prediction"]
                actual = str(row["FTR"])
                # map D->D, H/A same; X no-bet excluded
                if pred == "X":
                    continue
                p = "D" if pred == "D" else pred
                correct += int(p == actual)
                total += 1
                if p == "D":
                    draws_pred += 1
                    draws_correct += int(actual == "D")
            acc = (correct/total*100) if total else 0.0
            draw_acc = (draws_correct/draws_pred*100) if draws_pred else 0.0
            out.append({"lookback": lb, "threshold": th, "games": total, "accuracy_pct": round(acc,2), "draws_pred": draws_pred, "draws_correct": draws_correct, "draw_accuracy_pct": round(draw_acc,2)})
            self.config = cfg_old
        return pd.DataFrame(out).sort_values(["accuracy_pct","games"], ascending=[False,False]).reset_index(drop=True)
