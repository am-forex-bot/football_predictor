from __future__ import annotations
import json
from pathlib import Path
import pandas as pd
from .io_utils import _norm_team


def save_categories(path: str | Path, mapping: dict[str,str]) -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    clean = {str(_norm_team(k)): str(v).upper()[:1] for k,v in mapping.items() if str(v).upper()[:1] in {"A","B","C","D","E","F","G"}}
    p.write_text(json.dumps(clean, indent=2), encoding="utf-8")


def load_categories(path: str | Path) -> dict[str,str]:
    p = Path(path)
    if not p.exists():
        return {}
    raw = json.loads(p.read_text(encoding="utf-8"))
    return {str(_norm_team(k)): str(v).upper()[:1] for k,v in raw.items() if str(v).upper()[:1] in {"A","B","C","D","E","F","G"}}


def categories_from_table(table_df: pd.DataFrame, bins: list[tuple[int,int,str]]) -> dict[str,str]:
    mapping = {}
    for _, row in table_df.iterrows():
        pos = int(row["Pos"])
        team = str(row["Team"])
        cat = None
        for lo, hi, label in bins:
            if lo <= pos <= hi:
                cat = label
                break
        mapping[team] = cat or bins[-1][2]
    return mapping
