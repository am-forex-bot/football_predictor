from dataclasses import dataclass, field
from typing import Dict, List

@dataclass
class PredictorConfig:
    lookback: int = 6
    threshold: float = 2.0
    use_manual_categories: bool = True
    no_bet_band: float = 0.0
    season_col: str = "Season"
    category_labels: List[str] = field(default_factory=lambda: ["A","B","C","D","E","F","G"])
    # Weight tables indexed by result -> venue -> tier_group
    # tier_group keys expected: T1..T7 (best->worst)
    win_weights: Dict[str, Dict[str, float]] = field(default_factory=lambda: {
        "Home": {"T1":9,"T2":8,"T3":7,"T4":6,"T5":5,"T6":4,"T7":3},
        "Away": {"T1":10,"T2":9,"T3":8,"T4":7,"T5":6,"T6":5,"T7":4},
    })
    draw_weights: Dict[str, Dict[str, float]] = field(default_factory=lambda: {
        "Home": {"T1":7,"T2":6,"T3":5,"T4":4,"T5":3,"T6":2,"T7":1},
        "Away": {"T1":8,"T2":7,"T3":6,"T4":5,"T5":4,"T6":3,"T7":2},
    })
    # Close loss vs heavy loss by tier/venue
    loss_close_weights: Dict[str, Dict[str, float]] = field(default_factory=lambda: {
        "Home": {"T1":3,"T2":2,"T3":1,"T4":0,"T5":-1,"T6":-2,"T7":-3},
        "Away": {"T1":4,"T2":3,"T3":2,"T4":1,"T5":0,"T6":-1,"T7":-2},
    })
    loss_heavy_penalty: float = -1.0  # extra added for losses by >=2 goals
