from __future__ import annotations
import pandas as pd
from pathlib import Path
from typing import Optional, Tuple

TEAM_ALIASES = {
    "Man United": "Manchester United",
    "Man Utd": "Manchester United",
    "Man City": "Manchester City",
    "Spurs": "Tottenham",
    "Nott'm Forest": "Nottingham Forest",
    "Wolves": "Wolverhampton Wanderers",
}

REQ_RESULTS = {"Date", "HomeTeam", "AwayTeam"}
REQ_FIXTURES = {"Date", "HomeTeam", "AwayTeam"}


def _norm_team(name: str) -> str:
    if pd.isna(name):
        return name
    s = str(name).strip()
    return TEAM_ALIASES.get(s, s)


def read_csv_any(path: str | Path) -> pd.DataFrame:
    p = Path(path)
    if p.suffix.lower() in {".xlsx", ".xls"}:
        return pd.read_excel(p)
    return pd.read_csv(p)


def normalise_match_file(df: pd.DataFrame, season: Optional[str] = None) -> pd.DataFrame:
    missing = REQ_RESULTS - set(df.columns)
    if missing:
        raise ValueError(f"Missing required columns: {sorted(missing)}")
    out = df.copy()
    out["Date"] = pd.to_datetime(out["Date"], dayfirst=True, errors="coerce")
    out["HomeTeam"] = out["HomeTeam"].map(_norm_team)
    out["AwayTeam"] = out["AwayTeam"].map(_norm_team)

    # Standardise result columns if present (football-data style)
    if "FTR" not in out.columns and {"FTHG","FTAG"}.issubset(out.columns):
        def _ftr(r):
            if pd.isna(r["FTHG"]) or pd.isna(r["FTAG"]):
                return None
            if r["FTHG"] > r["FTAG"]: return "H"
            if r["FTHG"] < r["FTAG"]: return "A"
            return "D"
        out["FTR"] = out.apply(_ftr, axis=1)

    # Mark completed fixtures (fixtures.csv may not have result columns yet)
    fthg = out["FTHG"] if "FTHG" in out.columns else pd.Series([pd.NA] * len(out), index=out.index)
    ftag = out["FTAG"] if "FTAG" in out.columns else pd.Series([pd.NA] * len(out), index=out.index)
    ftr = out["FTR"] if "FTR" in out.columns else pd.Series([pd.NA] * len(out), index=out.index)
    out["is_completed"] = fthg.notna() & ftag.notna() & ftr.notna()
    if season is not None:
        out["Season"] = season
    elif "Season" not in out.columns:
        out["Season"] = out["Date"].dt.year.astype("Int64").astype(str)
    return out.sort_values(["Date","HomeTeam","AwayTeam"]).reset_index(drop=True)


def split_results_fixtures(df: pd.DataFrame) -> Tuple[pd.DataFrame,pd.DataFrame]:
    return df[df["is_completed"]].copy(), df[~df["is_completed"]].copy()


def latest_download_file(download_dir: str | Path, patterns: list[str]) -> Optional[Path]:
    d = Path(download_dir)
    candidates = []
    for pat in patterns:
        candidates.extend(d.glob(pat))
    if not candidates:
        return None
    return sorted(candidates, key=lambda p: p.stat().st_mtime, reverse=True)[0]


def filter_by_division(df: pd.DataFrame, div_code: str | None) -> pd.DataFrame:
    if not div_code or "Div" not in df.columns:
        return df.copy()
    out = df[df["Div"].astype(str).str.upper() == str(div_code).upper()].copy()
    return out
