# Football Match Predictor (Refactor Starter + Downloader)

This is a **starter rebuild** of your notebook predictor into Python files with a simple GUI.

## What it does already
- **Downloads** current results + fixtures CSVs from `football-data.co.uk`
- Load results + fixtures CSV/XLSX files (manual or downloaded)
- Auto-find likely latest files from Downloads folder
- Leak-aware backtest across **lookback** and **threshold** (same-season only)
- Predict upcoming fixtures using:
  - home-team home form (last N)
  - away-team away form (last N)
  - weighted scoring by opponent category and venue
- Manual team category assignment (`A`-`E`) saved to JSON
- Export predictions to CSV

## What it does *not* do yet
- Tune weighting values automatically (weights are configurable but not grid-searched yet)
- Download via paid APIs / live fixtures APIs (currently football-data.co.uk CSV pull)
- Multi-league presets / cross-league tuning
- Proper probability model / odds ROI testing

## Run

```bash
pip install pandas openpyxl
python app.py
```

## New GUI flow (no manual downloading needed)
1. Pick your **League** and **Season code** (e.g. `2526` for 2025/26)
2. Click **Download both**
3. Click **Load files**
4. Click **Edit categories** and assign `A-E`
5. Run **Backtest** and/or **Predict this week's fixtures**

## Expected columns (football-data style works)
- `Date`
- `HomeTeam`
- `AwayTeam`
- For completed results: `FTHG`, `FTAG`, `FTR`
- `Div` is used to filter `fixtures.csv` to your chosen league when present

If `FTR` is missing but goals are present, it will be generated automatically.

## Notes on sources
- Results file URL pattern used: `https://www.football-data.co.uk/mmz4281/{season_code}/{league_code}.csv`
- Fixtures file URL used: `https://www.football-data.co.uk/fixtures.csv`

## Next recommended build steps
1. Add **weight tuning grid / optimizer** over historical seasons
2. Add per-league weight profiles (EPL, Championship, Serie A, etc.)
3. Add richer category UI (table + dropdowns rather than text editor)
4. Add season boundary enforcement everywhere (including explicit matchweek/week-date views)
5. Add betting metrics (ROI, strike rate by odds band, no-bet zone)
