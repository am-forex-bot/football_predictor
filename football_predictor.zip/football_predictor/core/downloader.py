"""Download match data from football-data.co.uk.

Downloads both the season results CSV (which may contain upcoming fixtures
as rows with no FTR) AND the dedicated fixtures.csv which has all upcoming
fixtures across all leagues.
"""

import random
import time
from io import StringIO

import pandas as pd
import requests
from PyQt6.QtCore import QObject, QThread, pyqtSignal

from core.leagues import (get_results_url, get_past_season_codes, season_display,
                         get_fd_slug, get_current_season_code, FD_TEAM_MAP)

USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Mobile/15E148 Safari/604.1",
]

FIXTURES_URL = "https://www.football-data.co.uk/fixtures.csv"
FD_BASE_URL = "https://fixturedownload.com/download"


def _fetch_csv(url: str, retries: int = 5) -> str:
    """Download a CSV from the given URL with retry and UA rotation."""
    session = requests.Session()
    for attempt in range(retries):
        session.headers.update({"User-Agent": random.choice(USER_AGENTS)})
        try:
            resp = session.get(url, timeout=15)
            if resp.status_code == 200:
                return resp.text
            raise requests.HTTPError(f"HTTP {resp.status_code}")
        except requests.RequestException as exc:
            if attempt == retries - 1:
                raise RuntimeError(f"Failed to download {url} after {retries} attempts: {exc}") from exc
            time.sleep(2 ** attempt + random.uniform(0, 1))
    raise RuntimeError(f"Failed to download {url}")


def _parse_csv_text(text: str) -> pd.DataFrame:
    """Parse CSV text, handling BOM and encoding issues."""
    if text.startswith("\ufeff"):
        text = text[1:]
    return pd.read_csv(StringIO(text))


def download_results(league_code: str, season: str | None = None) -> pd.DataFrame:
    """Download a league's season CSV and return as DataFrame."""
    url = get_results_url(league_code, season)
    text = _fetch_csv(url)
    return _parse_csv_text(text)


def download_results_multi(league_code: str, n_seasons: int = 5,
                           progress_callback=None) -> list[tuple[str, pd.DataFrame]]:
    """Download multiple seasons. Returns [(season_code, df), ...] oldest first.

    Skips seasons that fail (e.g. league didn't exist yet) and continues.
    """
    codes = get_past_season_codes(n_seasons)
    results = []
    for i, code in enumerate(reversed(codes)):  # oldest first
        if progress_callback:
            progress_callback(f"Downloading {season_display(code)} ({i+1}/{n_seasons})...")
        try:
            df = download_results(league_code, code)
            if len(df) > 0:
                results.append((code, df))
        except Exception:
            if progress_callback:
                progress_callback(f"  Season {season_display(code)} not available, skipping")
    return results


def download_fixtures() -> pd.DataFrame:
    """Download the global fixtures.csv from football-data.co.uk."""
    text = _fetch_csv(FIXTURES_URL)
    return _parse_csv_text(text)


def download_fixtures_fd(league_code: str) -> pd.DataFrame:
    """Download fixtures from fixturedownload.com as a backup source.

    Returns a DataFrame with HomeTeam, AwayTeam, Date columns
    (team names mapped to football-data.co.uk convention).
    Returns empty DataFrame if not available for this league.
    """
    slug = get_fd_slug(league_code)
    if not slug:
        return pd.DataFrame()

    # Season code: fixturedownload uses start year, e.g. "epl-2025" for 2025-26
    season = get_current_season_code()
    start_year = 2000 + int(season[:2])
    url = f"{FD_BASE_URL}/{slug}-{start_year}-csv"

    try:
        text = _fetch_csv(url)
        df = _parse_csv_text(text)
    except Exception:
        return pd.DataFrame()

    # Expected columns: Round Number, Date, Location, Home Team, Away Team, Result
    if "Home Team" not in df.columns or "Away Team" not in df.columns:
        return pd.DataFrame()

    # Filter to unplayed matches (Result is empty or NaN)
    if "Result" in df.columns:
        unplayed = df["Result"].isna() | (df["Result"].str.strip() == "")
        df = df[unplayed].copy()

    if df.empty:
        return pd.DataFrame()

    # Map team names to football-data.co.uk convention
    df["HomeTeam"] = df["Home Team"].map(lambda t: FD_TEAM_MAP.get(t, t))
    df["AwayTeam"] = df["Away Team"].map(lambda t: FD_TEAM_MAP.get(t, t))

    # Parse date
    if "Date" in df.columns:
        df["Date"] = pd.to_datetime(df["Date"], dayfirst=True, errors="coerce")

    # Add dummy columns to match football-data format
    df["FTR"] = ""
    df["Div"] = league_code

    return df[["Div", "Date", "HomeTeam", "AwayTeam", "FTR"]].reset_index(drop=True)


# ---------------------------------------------------------------------------
# QThread workers for non-blocking GUI downloads
# ---------------------------------------------------------------------------

class DownloadWorker(QObject):
    """Runs downloads in a background thread, emitting progress signals."""

    progress = pyqtSignal(str)
    finished = pyqtSignal(dict)
    error = pyqtSignal(str)

    def __init__(self, league_code: str, n_seasons: int = 1, season: str | None = None):
        super().__init__()
        self.league_code = league_code
        self.n_seasons = n_seasons
        self.season = season

    def run(self):
        try:
            if self.n_seasons > 1:
                # Multi-season download
                self.progress.emit(
                    f"Downloading {self.n_seasons} seasons for {self.league_code}..."
                )
                season_data = download_results_multi(
                    self.league_code, self.n_seasons,
                    progress_callback=lambda msg: self.progress.emit(msg),
                )
                self.progress.emit(
                    f"  Got {len(season_data)} seasons of data"
                )

                # Current season is the last one (most recent)
                current_df = season_data[-1][1] if season_data else pd.DataFrame()
            else:
                self.progress.emit(f"Downloading results for {self.league_code}...")
                current_df = download_results(self.league_code, self.season)
                season_data = None  # single season mode

            total = len(current_df)
            played = current_df["FTR"].notna().sum() if "FTR" in current_df.columns else 0
            upcoming = total - played
            self.progress.emit(
                f"  Current season: {played} played, {upcoming} upcoming."
            )

            # Also download the dedicated fixtures file
            self.progress.emit("Downloading fixtures.csv (all leagues)...")
            league_fixtures = pd.DataFrame()
            try:
                fixtures_df = download_fixtures()
                if "Div" in fixtures_df.columns:
                    league_fixtures = fixtures_df[
                        fixtures_df["Div"] == self.league_code
                    ].copy()
                    self.progress.emit(
                        f"  Fixtures: {len(league_fixtures)} upcoming for {self.league_code} "
                        f"(from {len(fixtures_df)} total across all leagues)."
                    )
                else:
                    self.progress.emit(
                        f"  Fixtures: no Div column to filter by."
                    )
            except Exception as e:
                self.progress.emit(f"  Warning: Could not download fixtures.csv: {e}")

            # If no fixtures from football-data, try fixturedownload.com backup
            if league_fixtures.empty:
                self.progress.emit("Trying fixturedownload.com backup...")
                try:
                    fd_fixtures = download_fixtures_fd(self.league_code)
                    if not fd_fixtures.empty:
                        league_fixtures = fd_fixtures
                        self.progress.emit(
                            f"  Backup: {len(fd_fixtures)} future fixtures from fixturedownload.com"
                        )
                    else:
                        self.progress.emit("  Backup: no fixtures available either.")
                except Exception as e:
                    self.progress.emit(f"  Backup failed: {e}")

            self.finished.emit({
                "results": current_df,
                "fixtures": league_fixtures,
                "season_data": season_data,  # list of (code, df) or None
            })
        except Exception as exc:
            self.error.emit(str(exc))


def start_download(league_code: str, n_seasons: int = 1,
                   season: str | None = None) -> tuple[QThread, DownloadWorker]:
    """Create and start a download worker thread. Returns (thread, worker)."""
    thread = QThread()
    worker = DownloadWorker(league_code, n_seasons=n_seasons, season=season)
    worker.moveToThread(thread)
    thread.started.connect(worker.run)
    worker.finished.connect(thread.quit)
    worker.error.connect(thread.quit)
    thread.start()
    return thread, worker
